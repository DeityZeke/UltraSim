#!/usr/bin/env bash
set -euo pipefail

here="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
binary="$here/single-player/UltraSimSinglePlayer.x86_64"
createdump="$here/single-player/data_UltraSim.Client.Application.Godot_linuxbsd_x86_64/createdump"
cache="$here/warm-cache"
logs="$here/warm-logs"
results="$here/warm-results.tsv"

test -x "$binary"
test -f "$createdump"
chmod u+x "$createdump"
mkdir -p -- "$cache" "$logs"
printf 'phase\titeration\texit\tpass_marker\n' > "$results"

run_one() {
    local phase="$1" iteration="$2"
    local log="$logs/${phase}-${iteration}.log"
    local status marker=0
    set +e
    DOTNET_DbgEnableMiniDump=1 DOTNET_DbgMiniDumpType=4 \
      DOTNET_DbgMiniDumpName="$here/crash.%p.dmp" \
      timeout 90s "$binary" --headless -- \
      "--content-cache=$cache" --f1-4-official-smoke=installed > "$log" 2>&1
    status=$?
    set -e
    if rg -q 'F1.4 OFFICIAL LOCAL PASS mode=installed' "$log"; then marker=1; fi
    printf '%s\t%s\t%s\t%s\n' "$phase" "$iteration" "$status" "$marker" | tee -a "$results"
    if (( status != 0 || marker != 1 )); then
      printf 'Stopped at %s run %s; see %s\n' "$phase" "$iteration" "$log" >&2
      return 1
    fi
}

run_one cold 0
for iteration in $(seq 1 50); do run_one warm "$iteration"; done
