#include <X11/Xatom.h>
#include <X11/Xlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

// Xwayland can destroy an unrelated window while the enumeration is in flight.
static int ignore_bad_window(Display *display, XErrorEvent *error) {
    (void)display;
    if (error->error_code != BadWindow) {
        fprintf(stderr, "Unexpected X11 error %u\n", error->error_code);
        exit(6);
    }
    return 0;
}

static Window find_window(Display *display, Window parent, Atom pid_atom, long wanted_pid) {
    Atom actual_type;
    int actual_format;
    unsigned long count, bytes_after;
    unsigned char *value = NULL;
    if (XGetWindowProperty(display, parent, pid_atom, 0, 1, False, XA_CARDINAL,
            &actual_type, &actual_format, &count, &bytes_after, &value) == Success) {
        if (value != NULL && actual_format == 32 && count == 1 &&
                *(long *)value == wanted_pid) {
            XFree(value);
            return parent;
        }
        if (value != NULL) XFree(value);
    }
    Window root, parent_out, *children = NULL;
    unsigned int child_count = 0;
    if (!XQueryTree(display, parent, &root, &parent_out, &children, &child_count))
        return None;
    Window found = None;
    for (unsigned int index = 0; index < child_count && found == None; index++)
        found = find_window(display, children[index], pid_atom, wanted_pid);
    if (children != NULL) XFree(children);
    return found;
}

int main(int argc, char **argv) {
    if (argc != 2) return 2;
    long wanted_pid = strtol(argv[1], NULL, 10);
    if (wanted_pid <= 0) return 2;
    Display *display = XOpenDisplay(NULL);
    if (display == NULL) { fprintf(stderr, "No X11 display\n"); return 3; }
    XSetErrorHandler(ignore_bad_window);
    Atom pid_atom = XInternAtom(display, "_NET_WM_PID", False);
    Atom protocols = XInternAtom(display, "WM_PROTOCOLS", False);
    Atom wm_delete = XInternAtom(display, "WM_DELETE_WINDOW", False);
    Window window = None;
    for (int attempt = 0; attempt < 500 && window == None; attempt++) {
        window = find_window(display, DefaultRootWindow(display), pid_atom, wanted_pid);
        if (window == None) usleep(10000);
    }
    if (window == None) { fprintf(stderr, "Window not found for PID %ld\n", wanted_pid); XCloseDisplay(display); return 4; }
    XEvent event = {0};
    event.xclient.type = ClientMessage;
    event.xclient.window = window;
    event.xclient.message_type = protocols;
    event.xclient.format = 32;
    event.xclient.data.l[0] = wm_delete;
    event.xclient.data.l[1] = CurrentTime;
    int sent = XSendEvent(display, window, False, NoEventMask, &event);
    XFlush(display);
    XCloseDisplay(display);
    if (!sent) return 5;
    printf("Sent WM_DELETE_WINDOW to PID %ld window 0x%lx\n", wanted_pid, window);
    return 0;
}
