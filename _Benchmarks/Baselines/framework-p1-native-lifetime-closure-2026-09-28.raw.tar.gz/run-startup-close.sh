#!/usr/bin/env bash
set -euo pipefail

here="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
logs="$here/startup-logs"
results="$here/startup-results.tsv"
mkdir -p -- "$logs"
printf 'edition\titeration\texit\tready_marker\tpass_marker\n' > "$results"

for edition in SinglePlayer Online Complete; do
    case "$edition" in
        SinglePlayer) binary="$here/single-player/UltraSimSinglePlayer.x86_64" ;;
        Online) binary="$here/online/UltraSimOnline.x86_64" ;;
        Complete) binary="$here/complete/UltraSimComplete.x86_64" ;;
    esac
    test -x "$binary"
    for iteration in $(seq 1 10); do
        log="$logs/$edition-$iteration.log"
        set +e
        timeout 45s "$binary" --headless -- --composition-smoke \
          "--expect-edition=$edition" > "$log" 2>&1
        status=$?
        set -e
        ready=0 pass=0
        if rg -q 'ULTRASIM CLIENT READY' "$log"; then ready=1; fi
        if rg -q 'F0.1 CLIENT SHELL SMOKE PASS' "$log"; then pass=1; fi
        printf '%s\t%s\t%s\t%s\t%s\n' "$edition" "$iteration" "$status" "$ready" "$pass" | tee -a "$results"
        if (( status != 0 || ready != 1 || pass != 1 )); then
            printf 'Startup-close failure: %s run %s; see %s\n' "$edition" "$iteration" "$log" >&2
            exit 1
        fi
    done
done
