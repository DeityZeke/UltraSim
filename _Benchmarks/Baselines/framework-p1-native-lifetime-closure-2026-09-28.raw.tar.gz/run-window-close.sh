#!/usr/bin/env bash
set -euo pipefail

here="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
binary="$here/single-player/UltraSimSinglePlayer.x86_64"
helper="$here/send-wm-close"
results="$here/window-close-results.tsv"
mkdir -p -- "$here/window-logs"
printf 'iteration\thelp_exit\tclient_exit\tready_marker\n' > "$results"

for iteration in 1 2 3; do
    log="$here/window-logs/$iteration.log"
    "$binary" --display-driver x11 -- --expect-edition=SinglePlayer > "$log" 2>&1 &
    client_pid=$!
    set +e
    "$helper" "$client_pid"
    help_status=$?
    set -e
    if (( help_status != 0 )); then
        kill "$client_pid" 2>/dev/null || true
        wait "$client_pid" 2>/dev/null || true
        printf '%s\t%s\tN/A\tN/A\n' "$iteration" "$help_status" | tee -a "$results"
        exit 1
    fi
    for poll in $(seq 1 600); do
        if ! kill -0 "$client_pid" 2>/dev/null; then break; fi
        sleep 0.05
    done
    if kill -0 "$client_pid" 2>/dev/null; then
        kill "$client_pid" 2>/dev/null || true
        wait "$client_pid" 2>/dev/null || true
        printf '%s\t%s\tTIMEOUT\tN/A\n' "$iteration" "$help_status" | tee -a "$results"
        exit 1
    fi
    set +e
    wait "$client_pid"
    client_status=$?
    set -e
    marker=0
    if rg -q 'ULTRASIM CLIENT READY edition=Single Player' "$log"; then marker=1; fi
    printf '%s\t%s\t%s\t%s\n' "$iteration" "$help_status" "$client_status" "$marker" | tee -a "$results"
    if (( client_status != 0 || marker != 1 )); then exit 1; fi
done
